// Cartpole example with codegen, the code will be generated in the `tinympc_generated_code_cartpole_example` folder
// Build and run the example main function after generation

#include <iostream>
#ifdef __MINGW32__
#include <experimental/filesystem>
namespace std_fs = std::experimental::filesystem;
#else
#include <filesystem>
namespace std_fs = std::filesystem;
#endif

#include <tinympc/tiny_api.hpp>
#include <tinympc/codegen.hpp>

#define NSTATES 12   // state dimension: x (m), theta (rad), dx, dtheta
#define NINPUTS 4   // input dimension: F (Newtons)
#define NHORIZON 10 // horizon

extern "C" {

typedef Matrix<tinytype, NINPUTS, NHORIZON-1> tiny_MatrixNuNhm1;
typedef Matrix<tinytype, NSTATES, NHORIZON> tiny_MatrixNxNh;

std_fs::path output_dir_relative = "tinympc_generated_code_quadrotor100hz/";

int main()
{
    TinySolver *solver;

    tinytype rho_value = 1.0;

    // Discrete, linear model of upright cartpole.
    tinytype Adyn_data[NSTATES * NSTATES] = {1.000e+00, 0.000e+00, 0.000e+00, 1.000e-02, 0.000e+00, 0.000e+00, 0.000e+00,-4.905e-04, 0.000e+00, 0.000e+00,-1.635e-06, 0.000e+00,
                                            0.000e+00, 1.000e+00, 0.000e+00, 0.000e+00, 1.000e-02, 0.000e+00, 4.905e-04, 0.000e+00, 0.000e+00, 1.635e-06, 0.000e+00, 0.000e+00,
                                            0.000e+00, 0.000e+00, 1.000e+00, 0.000e+00, 0.000e+00, 1.000e-02, 0.000e+00, 0.000e+00, 0.000e+00, 0.000e+00, 0.000e+00, 0.000e+00,
                                            0.000e+00, 0.000e+00, 0.000e+00, 1.000e+00, 0.000e+00, 0.000e+00, 0.000e+00,-9.810e-02, 0.000e+00, 0.000e+00,-4.905e-04, 0.000e+00,
                                            0.000e+00, 0.000e+00, 0.000e+00, 0.000e+00, 1.000e+00, 0.000e+00, 9.810e-02, 0.000e+00, 0.000e+00, 4.905e-04, 0.000e+00, 0.000e+00,
                                            0.000e+00, 0.000e+00, 0.000e+00, 0.000e+00, 0.000e+00, 1.000e+00, 0.000e+00, 0.000e+00, 0.000e+00, 0.000e+00, 0.000e+00, 0.000e+00,
                                            0.000e+00, 0.000e+00, 0.000e+00, 0.000e+00, 0.000e+00, 0.000e+00, 1.000e+00, 0.000e+00, 0.000e+00, 1.000e-02, 0.000e+00, 0.000e+00,
                                            0.000e+00, 0.000e+00, 0.000e+00, 0.000e+00, 0.000e+00, 0.000e+00, 0.000e+00, 1.000e+00, 0.000e+00, 0.000e+00, 1.000e-02, 0.000e+00,
                                            0.000e+00, 0.000e+00, 0.000e+00, 0.000e+00, 0.000e+00, 0.000e+00, 0.000e+00, 0.000e+00, 1.000e+00, 0.000e+00, 0.000e+00, 1.000e-02,
                                            0.000e+00, 0.000e+00, 0.000e+00, 0.000e+00, 0.000e+00, 0.000e+00, 0.000e+00, 0.000e+00, 0.000e+00, 1.000e+00, 0.000e+00, 0.000e+00,
                                            0.000e+00, 0.000e+00, 0.000e+00, 0.000e+00, 0.000e+00, 0.000e+00, 0.000e+00, 0.000e+00, 0.000e+00, 0.000e+00, 1.000e+00, 0.000e+00,
                                            0.000e+00, 0.000e+00, 0.000e+00, 0.000e+00, 0.000e+00, 0.000e+00, 0.000e+00, 0.000e+00, 0.000e+00, 0.000e+00, 0.000e+00, 1.000e+00};
    tinytype Bdyn_data[NSTATES * NINPUTS] = { 0.00000000e+00, 0.00000000e+00,-1.70660933e-04, 0.00000000e+00,
                                            0.00000000e+00, 1.70660933e-04, 0.00000000e+00, 0.00000000e+00,
                                            -1.85185185e-03, 0.00000000e+00, 0.00000000e+00, 0.00000000e+00,
                                            0.00000000e+00, 0.00000000e+00,-6.82643731e-02, 0.00000000e+00,
                                            0.00000000e+00, 6.82643731e-02, 0.00000000e+00, 0.00000000e+00,
                                            -3.70370370e-01, 0.00000000e+00, 0.00000000e+00, 0.00000000e+00,
                                            0.00000000e+00, 2.08759551e+00, 0.00000000e+00, 0.00000000e+00,
                                            0.00000000e+00, 0.00000000e+00, 2.08759551e+00, 0.00000000e+00,
                                            0.00000000e+00, 0.00000000e+00, 0.00000000e+00, 1.54573840e+00,
                                            0.00000000e+00, 4.17519101e+02, 0.00000000e+00, 0.00000000e+00,
                                            0.00000000e+00, 0.00000000e+00, 4.17519101e+02, 0.00000000e+00,
                                            0.00000000e+00, 0.00000000e+00, 0.00000000e+00, 3.09147680e+02};
    tinytype Q_data[NSTATES] = {40000, 40000, 70000, 1600, 1600, 1600, 1500, 1500, 1500, 50, 50, 50};
    tinytype R_data[NINPUTS] = {1.0, 1.0, 1.0, 1.0};

    tinyMatrix Adyn = Map<Matrix<tinytype, NSTATES, NSTATES, RowMajor>>(Adyn_data);
    tinyMatrix Bdyn = Map<Matrix<tinytype, NSTATES, NINPUTS>>(Bdyn_data);
    tinyVector Q = Map<Matrix<tinytype, NSTATES, 1>>(Q_data);
    tinyVector R = Map<Matrix<tinytype, NINPUTS, 1>>(R_data);

    tinyMatrix x_min = tiny_MatrixNxNh::Constant(-1e17);
    tinyMatrix x_max = tiny_MatrixNxNh::Constant(1e17);
    tinyMatrix u_min = tiny_MatrixNuNhm1::Constant(-1e17);
    tinyMatrix u_max = tiny_MatrixNuNhm1::Constant(1e17);

    int verbose = 0;
    int status = tiny_setup(&solver,
                            Adyn, Bdyn, Q.asDiagonal(), R.asDiagonal(),
                            rho_value, NSTATES, NINPUTS, NHORIZON,
                            x_min, x_max, u_min, u_max, verbose);

    tiny_codegen(solver, std_fs::absolute(output_dir_relative).string().c_str(), verbose);

    return 0;
}

} /* extern "C" */
