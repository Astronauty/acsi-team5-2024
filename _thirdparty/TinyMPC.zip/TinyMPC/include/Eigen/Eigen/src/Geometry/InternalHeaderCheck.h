#ifndef EIGEN_GEOMETRY_MODULE_H
#error "Please include Eigen/Geometry instead of including headers inside the src directory directly."
#endif
